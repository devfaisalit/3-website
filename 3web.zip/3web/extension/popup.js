document.getElementById("search-btn").addEventListener("click", async () => {
    const keyword = document.getElementById("keyword").value; // Get the keyword from the input field
  
    if (!keyword) {
      alert("Please enter a keyword!");
      return;
    }
  
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: sendKeywordToGoogle,
      args: [keyword], // Pass the keyword to the injected function
    });
  });
  
  // Injected function to send the keyword to the search bar and click the button
  function sendKeywordToGoogle(keyword) {
    const searchInput = document.querySelector("input[name='q']"); // Google search input field
    const searchButton = document.querySelector("input[name='btnK']"); // Google search button
  
    if (searchInput) {
      searchInput.value = keyword; // Set the keyword in the input field
      searchInput.dispatchEvent(new Event("input", { bubbles: true })); // Trigger input event
    } else {
      console.error("Search input not found.");
      return;
    }
  
    if (searchButton) {
      searchButton.click(); // Click the search button
    } else {
      console.error("Search button not found.");
    }
  }
  